package com.example.mymybus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class login extends AppCompatActivity {

    Button loginBtn;
    EditText eml,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginBtn = (Button)findViewById(R.id.login);
        eml = (EditText)findViewById(R.id.email);
        pass = (EditText)findViewById(R.id.password);

    }


    public void checkLogin(View arg0) {
        new yourDataTask().execute();
    }

    protected class yourDataTask extends AsyncTask<Void, Void, JSONObject>
    {
        @Override
        protected JSONObject doInBackground(Void... params)
        {
            final String email = eml.getText().toString();
            final String password = pass.getText().toString();

            String str="https://ahmerdev.online/app_login.php?api=qw4hd-dqcrg&email="+email+"&password="+password;
            URLConnection urlConn = null;
            BufferedReader bufferedReader = null;
            try
            {
                URL url = new URL(str);
                urlConn = url.openConnection();
                bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));

                StringBuffer stringBuffer = new StringBuffer();
                String line;
                while ((line = bufferedReader.readLine()) != null)
                {
                    stringBuffer.append(line);
                }
                return new JSONObject(stringBuffer.toString());
            }
            catch(Exception ex)
            {
                Log.e("App", "yourDataTask", ex);
                return null;
            }
            finally
            {
                if(bufferedReader != null)
                {
                    try {
                        bufferedReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        @Override
        protected void onPostExecute(JSONObject response)
        {
            if(response != null)
            {
                String status = response.optString("status");
                if(status.equals("Login Success")){
                    int userid = 1;
                    Toast.makeText(getApplicationContext(), status , Toast.LENGTH_SHORT).show();
                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(login.this);
                    prefs.edit().putInt("userid",userid).commit();

                    Intent intent = new Intent(login.this, MapsActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), status , Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


    public void goToRegister(View view) {
        Intent intent = new Intent(login.this, register .class);
        startActivity(intent);
    }
}