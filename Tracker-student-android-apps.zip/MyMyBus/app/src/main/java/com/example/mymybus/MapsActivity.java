package com.example.mymybus;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Camera;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.StorageReference;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {


    //Adding Google Maps
    private GoogleMap mMap;

    //FireBase Realtime Connection
    private DatabaseReference db, bus, loc_db;
    Marker myMarker, busMarker, userLocation;

    //Adding Current Location
    Location currentLocation;

    //Firebase Connection
    private FirebaseFirestore mydb;

    //List to add Bus Markers
    List<Marker> myMarkersArray;


    private static final String TAG = MapsActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        loc_db = FirebaseDatabase.getInstance().getReference("Loc_db");
        db = FirebaseDatabase.getInstance().getReference("Stops-101");
        mydb = FirebaseFirestore.getInstance();
        readChanges();

        //Array of Bus Markers Addition
        myMarkersArray = new ArrayList<>();
    }


    /*========================Show Markers from Database===========================*/
    private void readChanges() {
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot data : snapshot.getChildren()) {
                        Double lat = data.child("latitude").getValue(Double.class);
                        Double lng = data.child("longitude").getValue(Double.class);
                        String stops = data.child("stopInfo").getValue(String.class);
                        String texting = "Latitude: " + lat + " Longitude: " + lng + " "+stops;
                        float hue = 36f;

                        Log.d("TAG", texting);
                        LatLng myMarkers = new LatLng(lat, lng);
                        myMarker = mMap.addMarker(new MarkerOptions().position(myMarkers)
                                .title(stops)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker))
                                .anchor(0.5f, 1));
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(myMarkers, 13));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        /*========================Show Bus Current Position===========================*/
        loc_db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    removeBusMarkers();
                    for (DataSnapshot data : snapshot.getChildren()) {
                        Double lat = data.child("Coordinates").child("Latitude").getValue(Double.class);
                        Double lng = data.child("Coordinates").child("Longitude").getValue(Double.class);
                        String title = data.child("Coordinates").child("Route").getValue(String.class);
                        setBusMarkers(lat, lng, title);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    /*========================Show NFC IET University Marker===========================*/
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng nfc = new LatLng(30.219952, 71.537314);
        myMarker = mMap.addMarker(new MarkerOptions().position(nfc).title("NFC IET").icon(BitmapDescriptorFactory.fromResource(R.drawable.nfc)));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(nfc, 8));
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setAllGesturesEnabled(true);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(nfc));
        boolean success = googleMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(
                        this, R.raw.style));
    }

    //Logout Function
    public void logout(View arg0) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(MapsActivity.this);
        prefs = PreferenceManager.getDefaultSharedPreferences(MapsActivity.this);
        prefs.edit().clear().commit();
        Intent intent = new Intent(MapsActivity.this, login .class);
        startActivity(intent);

    }


    //Adding Mus Markers
    public void setBusMarkers(Double lat, Double lng, String title){
        LatLng myMarkers = new LatLng(lat, lng);
        myMarker = mMap.addMarker(new MarkerOptions().position(myMarkers)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.busicon))
                .title(title)
                .anchor(0.5f, 1));
        myMarkersArray.add(myMarker);

    }

    //Removing all bus Markers
    public void removeBusMarkers(){
        for (int k = 0; k < myMarkersArray.size(); k++) {
            myMarkersArray.get(k).remove();
        }
        myMarkersArray.clear();
    }
}