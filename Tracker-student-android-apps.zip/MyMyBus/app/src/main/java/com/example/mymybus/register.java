package com.example.mymybus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class register extends AppCompatActivity {

    Button registerBtn;
    EditText eml,pass1, pass2, roll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        registerBtn = (Button)findViewById(R.id.registerBtn);
        eml = (EditText)findViewById(R.id.email);
        roll = (EditText)findViewById(R.id.rollnumber);
        pass1 = (EditText)findViewById(R.id.password1);
        pass2 = (EditText)findViewById(R.id.password2);
    }

    public void checkRegister(View arg0) {
        new yourDataTask().execute();
    }

    protected class yourDataTask extends AsyncTask<Void, Void, JSONObject>
    {
        @Override
        protected JSONObject doInBackground(Void... params)
        {
            final String email = eml.getText().toString();
            final String password1 = pass1.getText().toString();
            final String password2 = pass2.getText().toString();
            final String rollnumber = roll.getText().toString();

            String str="https://ahmerdev.online/app_register.php?api=qw4hd-dqcrg&email="+email+"&password1="+password1+"&password2="+password2+"&rollnumber="+rollnumber;
            URLConnection urlConn = null;
            BufferedReader bufferedReader = null;
            try
            {
                URL url = new URL(str);
                urlConn = url.openConnection();
                bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));

                StringBuffer stringBuffer = new StringBuffer();
                String line;
                while ((line = bufferedReader.readLine()) != null)
                {
                    stringBuffer.append(line);
                }

                return new JSONObject(stringBuffer.toString());
            }
            catch(Exception ex)
            {
                Log.e("App", "yourDataTask", ex);
                return null;
            }
            finally
            {
                if(bufferedReader != null)
                {
                    try {
                        bufferedReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        @Override
        protected void onPostExecute(JSONObject response)
        {
            if(response != null)
            {
                String status = response.optString("status");
                if(status.equals("Register Success")){
                    Toast.makeText(getApplicationContext(), status , Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(register.this, login .class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), status , Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    public void goToLogin(View view) {
        Intent intent = new Intent(register.this, login .class);
        startActivity(intent);
    }
}