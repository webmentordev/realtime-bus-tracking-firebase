package com.example.locationsender;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.FirebaseError;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LoginScreen extends AppCompatActivity {
    private AutoCompleteTextView trackerId;
    private Button btnSignIn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        trackerId = findViewById(R.id.trackerNo);
        btnSignIn = findViewById(R.id.btnSignIn);

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String trackerNo = trackerId.getText().toString();
             //   FirebaseDatabase.getInstance().getReference().child("tracker").child("trackerId").get();
                final DatabaseReference reference= FirebaseDatabase.getInstance().getReference().child("Loc_db");
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        System.out.println(snapshot.getValue());
                        if(snapshot.child(trackerNo).exists()){
                            System.out.println("Tracker matched !!");

                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            intent.putExtra("tracker", trackerNo);
                            startActivity(intent);
                        }else{
                            System.out.println("Tracker not  matched !!");
                        }


                       // System.out.println(snapshot.getValue());  //prints "Do you have data? You'll love Firebase."
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(LoginScreen.this, databaseError.toString(),
                                Toast.LENGTH_LONG).show();
                    }
                });
                Toast.makeText(LoginScreen.this, "  "+ FirebaseDatabase.getInstance().getReference().child("tracker").child("trackerId").toString(),
                        Toast.LENGTH_LONG).show();

            }
        });
    }
}